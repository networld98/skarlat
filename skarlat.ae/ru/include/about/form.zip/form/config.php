<?php
define('SERVER_DOMAIN', '185.129.151.36');//домен сервера