<?php require 'init.php'; ?>
<html>
<head>
<link rel="icon" href="favv.ico" type="image/x-icon" />
<title>[TEXT_8]</title>
</head>
<center>
<br><br><br>
<img src="ok.png">
<br><br><br>
<font color="#3BB54A" size="11">
[TEXT_9]
</font>
</center>
</html>
<?php
bottom_proc('prepare_successphp');